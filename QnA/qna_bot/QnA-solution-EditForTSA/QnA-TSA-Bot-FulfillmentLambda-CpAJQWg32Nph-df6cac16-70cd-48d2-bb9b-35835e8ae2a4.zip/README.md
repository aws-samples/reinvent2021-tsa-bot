# Fulfilment Lambda
This is the lambda that fulfills Lex and Alexa requests. 

## Tests
test are run using:
```shell
npm test
```

or
```shell
npm unit {{test-name}}
```

