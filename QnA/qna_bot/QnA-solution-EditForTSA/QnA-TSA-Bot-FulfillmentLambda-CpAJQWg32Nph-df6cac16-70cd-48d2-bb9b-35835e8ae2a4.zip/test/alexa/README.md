collection of example alexa request objects
and schema for response object
