Middleware functions for fulfilment lambda. All behavior for the fulfillment lambda is defiend in the functions.

the general form for the middleware is 
```js
module.exports=function(request,response){

}
```

the middleware can return a promise for async operation. 
